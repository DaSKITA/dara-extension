export default function () {
    return 'key';
}